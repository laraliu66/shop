package com.sl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sl.entity.Transaction;
import com.sl.server.TransaOrderService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=ApiAppliction.class) 
public class InsertTest {
	
	@Autowired
	private TransaOrderService ts ;
	
	@Test
	public void testAdd() {
		Transaction t = new Transaction();
		t.setTransactionID(1);
		t.setTradeID(1);
		t.setVersion(1);
		t.setSecurityCode("REL");
		t.setQuantity(50);
		t.setOperation("INSERT");
		t.setTransaType("Buy");
		ts.add(t);
	}
}
