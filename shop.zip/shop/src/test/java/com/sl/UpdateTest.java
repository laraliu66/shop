package com.sl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.sl.entity.Transaction;
import com.sl.server.TransaOrderService;

public class UpdateTest {
	
	@Autowired
	private TransaOrderService ts ;
	
	@Test
	public void testUpdate() {
		Transaction t = new Transaction();
		t.setTransactionID(1);
		t.setTradeID(1);
		t.setVersion(1);
		t.setSecurityCode("REL");
		t.setQuantity(50);
		t.setOperation("INSERT");
		t.setTransaType("Buy");
		ts.add(t);
	}
}
