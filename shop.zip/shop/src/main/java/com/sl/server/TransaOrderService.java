package com.sl.server;

import com.sl.entity.Transaction;

public interface TransaOrderService {
	
	
	public void operation(Transaction t);
	
	public void add(Transaction t);
	
	public void update(Transaction t);
	
	public void cancel(Transaction t);
	
	
}
