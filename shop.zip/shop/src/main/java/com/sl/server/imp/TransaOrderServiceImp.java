package com.sl.server.imp;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.sl.entity.Transaction;
import com.sl.server.TransaOrderService;

@Service
public class TransaOrderServiceImp implements TransaOrderService{
	
	private ArrayList<Transaction> list = new ArrayList<>();
	
	/**
	 * INSERT 
	 */
	@Override
	public void add(Transaction t) {
		// TODO Auto-generated method stub
		updateList(t);
	}
	
	/**
	 * update
	 */
	@Override
	public void update(Transaction t) {
		// TODO Auto-generated method stub
		if(null != t && null != t.getOperation() && null != t.getTransaType()) {
			if(t.getOperation().equals("UPDATE") && t.getTransaType().contentEquals("Buy")) {
				updateList(t);
			}
		}
	}
	/**
	 * cancel
	 */
	@Override
	public void cancel(Transaction t) {
		// TODO Auto-generated method stub
		if(null != t && null != t.getOperation() && null != t.getTransaType()) {
			if(t.getOperation().equals("CANCEL") && t.getTransaType().contentEquals("Buy")) {
				cancelList(t);
			}
		}
	}
	
	
	private void updateList(Transaction t) {
		if(list != null && list.size() > 0) {
			for(int i=0; i<list.size(); i++) {
				if(list.get(i).getTransactionID()==t.getTransactionID() && list.get(i).getTradeID()==t.getTradeID() 
						&& list.get(i).getVersion()==t.getVersion() && list.get(i).getSecurityCode().equals(t.getSecurityCode()) ) {
					list.get(i).setQuantity(list.get(i).getQuantity()+t.getQuantity());
					break;
				}else {
					list.add(t);
				}
			}
			print(list);
			//redis.setList(list);
		}else {
			list.add(t);
			print(list);
		}
	}
	
	private void cancelList(Transaction t) {
		if(list != null && list.size() > 0) {
			list.stream().forEach(o -> {
				if(t.getTransactionID()==o.getTransactionID()) {
					int tmp = o.getQuantity() - t.getQuantity();
					list.remove(t);
					o.setQuantity(tmp);
					list.add(o);
				}
			});
			print(list);
		}
	}
	

	@Override
	public void operation(Transaction t) {
		// TODO Auto-generated method stub
	}
	
	private void print(ArrayList<Transaction> list) {
		if(list != null && list.size() > 0) {
			System.out.println();
			System.out.println("-------------------------------------------------------------------");
			System.out.println("TransactionID   TradeID   Version  SecurityCode  Quantity  Insert/Update/Cancel  Buy/Sell");
			list.stream().forEach(o -> {
				System.out.println("     "+o.getTransactionID()+"             "+o.getTradeID()+"         "
							+o.getVersion()+"           "+o.getSecurityCode()+"       "+o.getQuantity()+"         "
							+o.getOperation()+"              "+o.getTransaType());
				
			});
			System.out.println("-------------------------------------------------------------------");
			System.out.println();
		}
	}

}
