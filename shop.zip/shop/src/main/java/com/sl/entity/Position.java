package com.sl.entity;

public class Position {
	
	private String SecurityCodeName;
	private int quantity;
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getSecurityCodeName() {
		return SecurityCodeName;
	}
	public void setSecurityCodeName(String securityCodeName) {
		SecurityCodeName = securityCodeName;
	}
	
}
