package com.sl.entity;

public class Transaction {
	
	private int transactionID;
	private int tradeID;
	private int version;
	private String securityCode;
	private int quantity;
	//insert,update,cancel
	private String operation; 
	//buy,sell 交易类型
	private String transaType; 
	
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public int getTradeID() {
		return tradeID;
	}
	public void setTradeID(int tradeID) {
		this.tradeID = tradeID;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getSecurityCode() {
		return securityCode;
	}
	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getTransaType() {
		return transaType;
	}
	public void setTransaType(String transaType) {
		this.transaType = transaType;
	}
	
	
}
